# -*- coding: utf-8 -*-
{
    'name': 'Offline Barcode Scanner',
    'version': '18.0.1.1.0',
    'category': 'Inventory/Tools',
    'summary': 'Standalone full-screen barcode scanner — loads products '
               'into cache on first open and works completely offline. '
               'Scan → see product details for 5 seconds → back to scan.',
    'description': """
Offline Barcode Scanner
=======================
A POS-style standalone app that loads in a new browser tab. On first
open, it caches all active product basic info (id, name, default_code,
barcode, list_price, qty_available, image_128) into the browser's
IndexedDB. From then on, it works **completely offline** — scan a
barcode, see product details for 5 seconds, then bounce back to the
scan screen automatically.

Use cases:
- Warehouse staff checking stock at a receiving dock with spotty wifi
- Retail floor staff answering "is this in stock?" questions
- Any barcode-to-info lookup where you don't want to round-trip to the
  server for every scan.

Architecture:
- Served as a standalone HTML page like /pos/web — no backend OWL chrome
- Its own asset bundle (barcode_scanner.assets) — tiny, loads fast
- Product cache lives in IndexedDB via a simple wrapper
- Hidden input captures barcode scanner keystrokes (keyboard wedge mode)
- Auto-refresh cache button for when new products are added
- Works offline once cache is populated
""",
    'author': 'Waqas Riasat',
    'website': 'https://way4tech.com',
    'license': 'LGPL-3',
    'depends': [
        'web',
        'product',
        'stock',
    ],
    'data': [
        'security/ir.model.access.csv',
        'views/barcode_scanner_templates.xml',
        'views/barcode_scanner_menus.xml',
    ],
    'assets': {
        # Dedicated bundle for the standalone page — kept minimal on
        # purpose. Imports from @web are allowed because the shared
        # runtime is already on the page.
        'odoo_barcode_scanner_offline.assets': [
            ('include', 'web._assets_helpers'),
            ('include', 'web._assets_backend_helpers'),
            'web/static/src/scss/pre_variables.scss',
            'web/static/lib/bootstrap/scss/_variables.scss',
            'web/static/lib/bootstrap/scss/_variables-dark.scss',
            'web/static/lib/bootstrap/scss/_maps.scss',
            ('include', 'web._assets_bootstrap_backend'),
            ('include', 'web._assets_core'),

            'web/static/src/libs/fontawesome/css/font-awesome.css',
            'web/static/src/webclient/icons.scss',

            'odoo_barcode_scanner_offline/static/src/**/*',
        ],
    },
    'installable': True,
    'application': True,
    'auto_install': False,
}
