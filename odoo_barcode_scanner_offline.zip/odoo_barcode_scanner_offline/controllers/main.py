# -*- coding: utf-8 -*-
"""Controller endpoints for the offline barcode scanner app.

/barcode_scanner  — renders the standalone HTML page (like /pos/web)
/barcode_scanner/products  — JSON: dump of all active products for
                             the initial cache load.
"""
import base64
import logging

from odoo import http
from odoo.http import request

_logger = logging.getLogger(__name__)


class BarcodeScannerController(http.Controller):

    @http.route('/barcode_scanner', type='http', auth='user')
    def scanner_page(self, **kw):
        """Render the standalone scanner HTML page.

        Must be an internal user — the whole point is that it's an
        employee tool, not a public endpoint.
        """
        if not request.env.user._is_internal():
            return request.not_found()
        session_info = request.env['ir.http'].session_info()
        company = request.env.company
        currency = company.currency_id
        context = {
            'session_info': session_info,
            'currency_symbol': currency.symbol or '',
            'currency_position': currency.position or 'before',
            'company_name': company.name or '',
            'company_id': company.id,
        }
        response = request.render(
            'odoo_barcode_scanner_offline.index', context)
        response.headers['Cache-Control'] = 'no-store'
        return response

    @http.route('/barcode_scanner/products', type='json', auth='user')
    def scanner_products(self, **kw):
        """Return every active product needed to populate the offline cache.

        Kept intentionally tiny — just enough for the detail screen to
        render without another RPC. Image is optional and base64-encoded
        so it survives IndexedDB storage.
        """
        if not request.env.user._is_internal():
            return {'error': 'access_denied'}
        Product = request.env['product.product'].sudo()
        # Batch-read for performance — one search, one bulk read.
        # Images are deliberately NOT loaded: keeps the payload tiny and
        # the IndexedDB cache fast. Add them back later if a customer asks.
        products = Product.search([
            ('active', '=', True),
            ('sale_ok', '=', True),
        ])
        rows = products.read([
            'id',
            'name',
            'default_code',
            'barcode',
            'list_price',
            'standard_price',
            'qty_available',
            'uom_id',
            'categ_id',
            'type',
        ])
        currency = request.env.company.currency_id
        for row in rows:
            row['uom_name'] = (row.get('uom_id') or [0, ''])[1]
            row['category'] = (row.get('categ_id') or [0, ''])[1]
            row.pop('uom_id', None)
            row.pop('categ_id', None)
        return {
            'products': rows,
            'count': len(rows),
            'currency_symbol': currency.symbol or '',
            'currency_position': currency.position or 'before',
        }

    @http.route('/barcode_scanner/lookup', type='json', auth='user')
    def scanner_lookup(self, barcode=None, **kw):
        """Server-side fallback lookup — used when a scanned barcode
        isn't in the local cache (e.g. a product added after the last
        sync). Returns the same row shape as /products above.
        """
        if not barcode:
            return {'product': None}
        if not request.env.user._is_internal():
            return {'error': 'access_denied'}
        Product = request.env['product.product'].sudo()
        product = Product.search([
            '|', ('barcode', '=', barcode),
            ('default_code', '=', barcode),
        ], limit=1)
        if not product:
            return {'product': None}
        row = product.read([
            'id', 'name', 'default_code', 'barcode',
            'list_price', 'standard_price', 'qty_available',
            'uom_id', 'categ_id', 'type',
        ])[0]
        currency = request.env.company.currency_id
        row['uom_name'] = (row.get('uom_id') or [0, ''])[1]
        row['category'] = (row.get('categ_id') or [0, ''])[1]
        row.pop('uom_id', None)
        row.pop('categ_id', None)
        return {
            'product': row,
            'currency_symbol': currency.symbol or '',
            'currency_position': currency.position or 'before',
        }
