/** @odoo-module **/

/**
 * Plain JSON-RPC wrapper — uses the session cookie so we don't need
 * the full web RPC service with its model-aware plumbing. Keeps the
 * asset bundle small.
 */

export async function jsonRpc(url, params = {}) {
    const response = await fetch(url, {
        method: "POST",
        headers: {
            "Content-Type": "application/json",
        },
        body: JSON.stringify({
            jsonrpc: "2.0",
            method: "call",
            params: params,
            id: Math.floor(Math.random() * 1000000),
        }),
    });
    if (!response.ok) {
        throw new Error(`HTTP ${response.status}`);
    }
    const data = await response.json();
    if (data.error) {
        throw new Error(data.error.data?.message || data.error.message || "RPC error");
    }
    return data.result;
}
