/** @odoo-module **/

/**
 * Tiny IndexedDB wrapper for the offline barcode scanner.
 *
 * One DB, two stores:
 *   - products     keyPath=id      (primary)
 *   - barcode_idx  keyPath=barcode (secondary index for O(1) lookup)
 *
 * We deliberately don't use indexes-on-objectstore because we want both
 * the `barcode` field AND the `default_code` field to be lookup keys,
 * so we maintain a second object store where each row is written twice
 * (once by barcode, once by default_code).
 */

const DB_NAME = "barcode_scanner_offline";
const DB_VERSION = 1;

/** Open (and create if needed) the IndexedDB database. */
export function openDb() {
    return new Promise((resolve, reject) => {
        const req = indexedDB.open(DB_NAME, DB_VERSION);
        req.onupgradeneeded = (event) => {
            const db = event.target.result;
            if (!db.objectStoreNames.contains("products")) {
                db.createObjectStore("products", { keyPath: "id" });
            }
            if (!db.objectStoreNames.contains("barcode_idx")) {
                // keyPath = the scanned string itself
                db.createObjectStore("barcode_idx", { keyPath: "key" });
            }
            if (!db.objectStoreNames.contains("meta")) {
                db.createObjectStore("meta", { keyPath: "key" });
            }
        };
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}

/** Bulk replace the product cache. */
export async function saveProducts(products) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(["products", "barcode_idx", "meta"], "readwrite");
        const prodStore = tx.objectStore("products");
        const idxStore = tx.objectStore("barcode_idx");
        const metaStore = tx.objectStore("meta");

        // Wipe old data first — full refresh is simpler and correct.
        prodStore.clear();
        idxStore.clear();

        for (const p of products) {
            prodStore.put(p);
            if (p.barcode) {
                idxStore.put({ key: String(p.barcode), product_id: p.id });
            }
            if (p.default_code) {
                idxStore.put({ key: String(p.default_code), product_id: p.id });
            }
        }
        metaStore.put({
            key: "last_sync",
            value: new Date().toISOString(),
            count: products.length,
        });

        tx.oncomplete = () => resolve({ count: products.length });
        tx.onerror = () => reject(tx.error);
    });
}

/** Look up a product by scanned code (barcode or default_code). */
export async function findByCode(code) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(["products", "barcode_idx"], "readonly");
        const idxStore = tx.objectStore("barcode_idx");
        const prodStore = tx.objectStore("products");

        const idxReq = idxStore.get(String(code));
        idxReq.onsuccess = () => {
            const row = idxReq.result;
            if (!row) {
                resolve(null);
                return;
            }
            const prodReq = prodStore.get(row.product_id);
            prodReq.onsuccess = () => resolve(prodReq.result || null);
            prodReq.onerror = () => reject(prodReq.error);
        };
        idxReq.onerror = () => reject(idxReq.error);
    });
}

/** Store a single product (used when the server-fallback lookup finds
 *  something not yet in the cache). */
export async function cacheProduct(product) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(["products", "barcode_idx"], "readwrite");
        tx.objectStore("products").put(product);
        const idxStore = tx.objectStore("barcode_idx");
        if (product.barcode) {
            idxStore.put({ key: String(product.barcode), product_id: product.id });
        }
        if (product.default_code) {
            idxStore.put({ key: String(product.default_code), product_id: product.id });
        }
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
    });
}

/** Last sync metadata — used to show "last updated X minutes ago" in the UI. */
export async function getLastSync() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(["meta"], "readonly");
        const req = tx.objectStore("meta").get("last_sync");
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
    });
}

/** Save currency info to meta store. */
export async function saveCurrency(symbol, position) {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(["meta"], "readwrite");
        tx.objectStore("meta").put({ key: "currency", symbol, position });
        tx.oncomplete = () => resolve(true);
        tx.onerror = () => reject(tx.error);
    });
}

/** Load currency info from meta store. */
export async function getCurrency() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(["meta"], "readonly");
        const req = tx.objectStore("meta").get("currency");
        req.onsuccess = () => resolve(req.result || null);
        req.onerror = () => reject(req.error);
    });
}

/** Total number of cached products. */
export async function countProducts() {
    const db = await openDb();
    return new Promise((resolve, reject) => {
        const tx = db.transaction(["products"], "readonly");
        const req = tx.objectStore("products").count();
        req.onsuccess = () => resolve(req.result);
        req.onerror = () => reject(req.error);
    });
}
