/** @odoo-module **/

import { Component, useState, onMounted, useRef, onWillStart, whenReady, mount } from "@odoo/owl";
import { getTemplate } from "@web/core/templates";

import { jsonRpc } from "./rpc";
import {
    saveProducts,
    findByCode,
    cacheProduct,
    getLastSync,
    countProducts,
} from "./db";

/**
 * Two-screen app:
 *   view = "scan"  → full-screen scanner, waiting for input
 *   view = "detail" → shows the found product for DETAIL_SECONDS, then auto-returns
 *
 * Scanner input handling:
 *   A hidden input is kept focused at all times. Keyboard-wedge
 *   barcode scanners type the code + Enter; we capture on Enter and
 *   look up in IndexedDB. If the cache misses AND we're online, we
 *   fall back to the server via /barcode_scanner/lookup.
 */

const DETAIL_SECONDS = 7;

export class ScannerApp extends Component {
    static template = "odoo_barcode_scanner_offline.App";
    static props = {};

    setup() {
        // Config is embedded in the page by the server — always available
        const cfg = window.__scanner_config__ || {};
        this.state = useState({
            view: "scan",        // "scan" | "detail" | "loading"
            status: "idle",      // "idle" | "scanning" | "not_found" | "cache_miss"
            product: null,
            cachedCount: 0,
            lastSync: null,
            online: navigator.onLine,
            message: "",
            syncing: false,
            timerRemaining: DETAIL_SECONDS,
            buffer: "",          // keyboard-wedge buffer
            currencySymbol: cfg.currency_symbol || "",
            currencyPosition: cfg.currency_position || "before",
            companyName: cfg.company_name || "",
            companyLogoUrl: cfg.company_logo_url || "",
        });
        this.inputRef = useRef("scanInput");
        this._detailTimer = null;
        this._countdownTimer = null;
        this._bufferTimer = null;

        onWillStart(async () => {
            const [count, sync] = await Promise.all([countProducts(), getLastSync()]);
            this.state.cachedCount = count;
            this.state.lastSync = sync ? sync.value : null;
            // First-run: if nothing cached, kick off a sync immediately
            if (count === 0 && navigator.onLine) {
                await this.refreshCache();
            }
        });

        onMounted(() => {
            this._focusInput();
            window.addEventListener("online", this._onOnline);
            window.addEventListener("offline", this._onOffline);
            document.addEventListener("keydown", this._onGlobalKeydown);
            // Refocus the hidden input whenever the user clicks anywhere
            document.addEventListener("click", this._focusInput);
            // Auto-reclaim focus whenever the input loses it (OWL re-render,
            // timer callbacks, etc.) — this is the main fix for the
            // "need to click to scan again" bug.
            if (this.inputRef.el) {
                this.inputRef.el.addEventListener("blur", this._onInputBlur);
            }
        });
    }

    _focusInput = () => {
        // Multiple delayed attempts — OWL re-render can steal focus after
        // state changes, so a single setTimeout(0) is not reliable.
        for (const delay of [0, 50, 150]) {
            setTimeout(() => {
                if (this.inputRef.el && document.activeElement !== this.inputRef.el) {
                    this.inputRef.el.focus();
                }
            }, delay);
        }
    };

    _onInputBlur = () => {
        // Re-grab focus after a short delay — gives time for intentional
        // interactions (like clicking the Refresh button) to complete first.
        setTimeout(() => {
            if (this.inputRef.el && document.activeElement !== this.inputRef.el) {
                this.inputRef.el.focus();
            }
        }, 100);
    };

    _onOnline = () => (this.state.online = true);
    _onOffline = () => (this.state.online = false);

    _onGlobalKeydown = (ev) => {
        // Let Escape bounce back from the detail view immediately
        if (ev.key === "Escape" && this.state.view === "detail") {
            this._backToScan();
            ev.preventDefault();
        }
    };

    /** Refresh the IndexedDB product cache from the server. */
    async refreshCache() {
        if (this.state.syncing) return;
        this.state.syncing = true;
        this.state.message = "Loading products…";
        try {
            const res = await jsonRpc("/barcode_scanner/products", {});
            if (!res || !res.products) {
                throw new Error("Bad response from server");
            }
            const { count } = await saveProducts(res.products);
            const sync = await getLastSync();
            this.state.cachedCount = count;
            this.state.lastSync = sync ? sync.value : new Date().toISOString();
            this.state.message = `Synced ${count} products`;
        } catch (e) {
            this.state.message = "Sync failed: " + (e.message || e);
        } finally {
            this.state.syncing = false;
            this._focusInput();
        }
    }

    onInputKeydown(ev) {
        if (ev.key === "Enter") {
            ev.preventDefault();
            const code = (this.state.buffer || ev.target.value || "").trim();
            if (code) {
                this._handleScan(code);
            }
            this.state.buffer = "";
            if (this.inputRef.el) this.inputRef.el.value = "";
        }
    }

    onInputChange(ev) {
        // Keep a running buffer so paste / slow typing still works
        this.state.buffer = ev.target.value;
    }

    async _handleScan(code) {
        this.state.status = "scanning";
        try {
            let product = await findByCode(code);
            if (!product && this.state.online) {
                // Server fallback — product might be new since last sync
                const res = await jsonRpc("/barcode_scanner/lookup", { barcode: code });
                if (res && res.product) {
                    product = res.product;
                    cacheProduct(product).catch(() => {});
                }
            }
            if (product) {
                this._showDetail(product);
            } else {
                this._showNotFound(code);
            }
        } catch (e) {
            this.state.message = "Lookup error: " + (e.message || e);
        }
    }

    _showDetail(product) {
        this.state.view = "detail";
        this.state.product = product;
        this.state.status = "idle";
        this.state.timerRemaining = DETAIL_SECONDS;

        // Kick off the auto-return timer + visual countdown
        this._clearTimers();
        this._countdownTimer = setInterval(() => {
            this.state.timerRemaining = Math.max(0, this.state.timerRemaining - 1);
        }, 1000);
        this._detailTimer = setTimeout(() => this._backToScan(), DETAIL_SECONDS * 1000);
        // Keep input focused so next scan works immediately
        this._focusInput();
    }

    _showNotFound(code) {
        this.state.view = "detail";
        this.state.product = { not_found: true, code };
        this.state.status = "not_found";
        this.state.timerRemaining = DETAIL_SECONDS;
        this._clearTimers();
        this._countdownTimer = setInterval(() => {
            this.state.timerRemaining = Math.max(0, this.state.timerRemaining - 1);
        }, 1000);
        this._detailTimer = setTimeout(() => this._backToScan(), DETAIL_SECONDS * 1000);
        this._focusInput();
    }

    _backToScan() {
        this._clearTimers();
        this.state.view = "scan";
        this.state.product = null;
        this.state.status = "idle";
        this.state.buffer = "";
        if (this.inputRef.el) {
            this.inputRef.el.value = "";
        }
        this._focusInput();
    }

    _clearTimers() {
        if (this._detailTimer) {
            clearTimeout(this._detailTimer);
            this._detailTimer = null;
        }
        if (this._countdownTimer) {
            clearInterval(this._countdownTimer);
            this._countdownTimer = null;
        }
    }

    /** Escape-trigger button on the detail screen */
    onCloseClick() {
        this._backToScan();
    }
}

// Mount immediately on page load — no services, no web client, just OWL.
whenReady(async () => {
    const root = document.getElementById("scanner-root");
    if (!root) {
        console.error("scanner-root mount point missing");
        return;
    }
    mount(ScannerApp, root, {
        getTemplate,
        dev: false,
    });
});
